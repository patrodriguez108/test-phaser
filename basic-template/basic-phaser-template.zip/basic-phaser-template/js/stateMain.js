var StateMain = {

    preload: function () {

    },

    create: function () {
        console.log("Ready!");
    },

    update: function () {

    }

}